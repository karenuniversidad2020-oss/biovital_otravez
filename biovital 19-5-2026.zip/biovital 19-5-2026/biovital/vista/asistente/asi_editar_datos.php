<?php
if($_SESSION['us_tipo'] == 3 && $_SESSION['rol'] == 'asistente'){
    // Incluir clase de seguridad para CSRF
    include_once '../../modelo/Security.php';
    
    include_once '../layouts/header.php';
?>
<title>Asistente | Editar datos</title>
<?php include_once '../layouts/nav_asistente.php'; ?>

<style>
    .select-group {
        margin-bottom: 15px;
    }
    .ubicacion-label {
        font-weight: 600;
        color: #0b7300;
        margin-bottom: 5px;
        display: block;
    }
    .help-text {
        font-size: 12px;
        color: #6c757d;
        margin-top: 5px;
    }
    .csrf-info {
        font-size: 12px;
        color: #6c757d;
        margin-top: 10px;
        text-align: center;
    }
    .required-field {
        color: #dc3545;
    }
</style>

<!-- Modal Cambiar Contraseña -->
<div class="modal fade" id="cambiocontra" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Cambiar contraseña</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="text-center">
          <img id="avatar3" src="../../img/avatar.png" class="profile-user-img img-fluid img-circle">
          <b><?php echo Security::sanitizar($_SESSION['nombre_us']); ?></b>
        </div>
        <div class="alert alert-success text-center" id="update" style="display:none;">Contraseña actualizada correctamente</div>
        <div class="alert alert-danger text-center" id="noupdate" style="display:none;">Contraseña actual incorrecta</div>
        <form id="form-pass" method="POST">
          <!-- TOKEN CSRF para cambio de contraseña -->
          <?php echo Security::campoCSRF(); ?>
          <input id="oldpass" type="password" class="form-control mb-2" placeholder="Contraseña actual" required>
          <input id="newpass" type="password" class="form-control" placeholder="Contraseña nueva" required>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-primary">Guardar</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal Cambiar Avatar -->
<div class="modal fade" id="cambiophoto" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Cambiar avatar</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div class="text-center">
          <img id="avatar3" src="../../img/avatarDES.jpg" class="profile-user-img img-fluid img-circle">
          <b><?php echo Security::sanitizar($_SESSION['nombre_us']); ?></b>
        </div>
        <div class="alert alert-success text-center" id="edit" style="display:none;">Avatar actualizado correctamente</div>
        <div class="alert alert-danger text-center" id="noedit" style="display:none;">Formato no admitido</div>
        <form id="form-photo" method="POST" enctype="multipart/form-data">
          <!-- TOKEN CSRF para cambio de foto -->
          <?php echo Security::campoCSRF(); ?>
          <input type="file" name="photo" class="form-control" accept="image/jpeg,image/png,image/gif" required>
          <input type="hidden" name="funcion" value="cambiar_foto">
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button type="submit" class="btn btn-primary">Guardar</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Contenido principal -->
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Datos personales</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="asi_catalogo.php">Home</a></li>
            <li class="breadcrumb-item active">Datos personales</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- PRIMER CARD -->
          <div class="col-md-3">
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img id="avatar2" src="../../img/avatarDES.jpg" class="profile-user-img img-fluid img-circle">
                </div>
                <div class='text-center mt-1'>
                  <button type='button' data-toggle="modal" data-target="#cambiophoto" class='btn btn-primary btn-sm'>Cambiar avatar</button>
                </div>
                <input id="id_usuario" type="hidden" value="<?php echo Security::sanitizar($_SESSION['usuario']); ?>">
                <h3 id="nombre_us" class="profile-username text-center text-primary">NOMBRE</h3>
                <p id="apellidos_us" class="text-muted text-center">Apellido</p>
                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b style="color:#0b7300">Edad</b>
                    <a id="edad" class="float-right">12</a>
                  </li>
                  <li class="list-group-item">
                    <b style="color:#0b7300">Cédula</b>
                    <a id="cedula_us" class="float-right">12</a>
                  </li>
                  <li class="list-group-item">
                    <b style="color:#0b7300">Tipo Usuario</b>
                    <span id="us_tipo" class="float-right badge badge-primary">Asistente</span>
                  </li>
                  <button data-toggle="modal" data-target="#cambiocontra" type="button" class="btn btn-block btn-outline-warning btn-sm">Cambiar contraseña</button>
                </ul>
              </div>
            </div>

            <!-- SEGUNDO CARD -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Sobre mi</h3>
              </div>
              <div class="card-body">
                <strong style="color:#0b7300"><i class="fas fa-phone mr-1"></i>Teléfono</strong>
                <p id="telefono_us" class="text-muted">-</p>
                <strong style="color:#0b7300"><i class="fas fa-map-marker-alt mr-1"></i>Dirección</strong>
                <p id="direccion_us" class="text-muted">-</p>
                <strong style="color:#0b7300"><i class="fas fa-at mr-1"></i>Correo</strong>
                <p id="correo_us" class="text-muted">-</p>
                <strong style="color:#0b7300"><i class="fas fa-smile-wink mr-1"></i>Sexo</strong>
                <p id="sexo_us" class="text-muted">-</p>
                <strong style="color:#0b7300"><i class="fas fa-pencil-alt mr-1"></i>Información adicional</strong>
                <p id="adicional_us" class="text-muted">-</p>
                <button class="edit btn btn-block bg-gradient-danger">Editar</button>
              </div>
              <div class="card-footer">
                <p class="text-muted">Click en el botón si desea editar</p>
              </div>
            </div>
          </div>

          <!-- TERCER CARD -->
          <div class="col-md-9">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Editar datos personales</h3>
              </div>
              <div class="card-body">
                <div class="alert alert-success text-center" id="editado" style="display:none;">
                  <span><i class="fas fa-check m-1"></i>Editado</span>
                </div>
                <div class="alert alert-danger text-center" id="noeditado" style="display:none;">
                  <span><i class="fas fa-times m-1"></i>Edición deshabilitada</span>
                </div>
                <form id="form-usuario" class="form-horizontal" method="POST">
                  <!-- TOKEN CSRF para edición de datos personales -->
                  <?php echo Security::campoCSRF(); ?>
                  
                  <div class="form-group row">
                    <label for="telefono" class="col-sm-2 col-form-label">Teléfono</label>
                    <div class="col-sm-10">
                      <input type="tel" id="telefono" class="form-control" placeholder="Ej: 04141234567">
                    </div>
                  </div>
                  
                  <!-- ==================== SISTEMA DE UBICACIÓN ==================== -->
                  <h4 class="mt-4"><i class="fas fa-map-marker-alt"></i> Ubicación</h4>
                  <hr>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="estado">Estado</label>
                        <select class="form-control" id="estado" name="estado" disabled>
                          <option value="">Seleccione un estado...</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="ciudad">Ciudad</label>
                        <select class="form-control" id="ciudad" name="ciudad" disabled>
                          <option value="">Seleccione un estado primero...</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="municipio">Municipio</label>
                        <select class="form-control" id="municipio" name="municipio" disabled>
                          <option value="">Seleccione una ciudad primero...</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="parroquia">Parroquia</label>
                        <select class="form-control" id="parroquia" name="parroquia" disabled>
                          <option value="">Seleccione un municipio primero...</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="direccion_detallada">Dirección Detallada</label>
                    <input type="text" class="form-control" id="direccion_detallada" name="direccion_detallada" placeholder="Av. Principal, Edificio, Número, etc.">
                    <small class="form-text text-muted">Ej: Av. Principal, Edificio Central, Piso 3</small>
                  </div>

                  <!-- Campo oculto para almacenar la dirección completa -->
                  <input type="hidden" id="direccion" name="direccion">
                  <!-- ==================== FIN SISTEMA DE UBICACIÓN ==================== -->
                  
                  <div class="form-group row">
                    <label for="correo" class="col-sm-2 col-form-label">Correo</label>
                    <div class="col-sm-10">
                      <input type="email" id="correo" class="form-control" placeholder="ejemplo@correo.com">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="sexo" class="col-sm-2 col-form-label">Sexo</label>
                    <div class="col-sm-10">
                      <select id="sexo" class="form-control">
                        <option value="">Seleccione...</option>
                        <option value="Masculino">Masculino</option>
                        <option value="Femenino">Femenino</option>
                        <option value="Otro">Otro</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="adicional" class="col-sm-2 col-form-label">Información adicional</label>
                    <div class="col-sm-10">
                      <textarea class="form-control" id="adicional" rows="5" placeholder="Información adicional sobre el asistente..."></textarea>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="offset-sm-2 col-sm-10 float-right">
                      <button type="submit" class="btn btn-block btn-outline-success">
                        <i class="fas fa-save"></i> Guardar Cambios
                      </button>
                    </div>
                  </div>
                </form>
              </div>
              <div class="card-footer">
                <div class="csrf-info">
                  <i class="fas fa-shield-alt"></i> Todos los cambios están protegidos contra falsificación de solicitudes (CSRF)
                </div>
                <p class="text-muted mt-2">Cuidado con ingresar datos erróneos</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php
include_once '../layouts/footer.php';
}
else{
    header('Location: ../login_asistente.php');
}
?>
<script src="../../js/asistente.js"></script>