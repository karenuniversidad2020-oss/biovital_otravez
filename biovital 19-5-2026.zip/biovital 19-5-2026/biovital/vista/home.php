<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BioVital - Sistema de Gestión Clínica</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/css/all.min.css">
    <style>
        .home-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .home-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .home-card img {
            width: 120px;
            margin-bottom: 20px;
        }
        .home-card h1 {
            color: #333;
            margin-bottom: 10px;
        }
        .home-card p {
            color: #666;
            margin-bottom: 30px;
        }
        .btn-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .btn-role {
            padding: 15px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: transform 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .btn-role:hover {
            transform: scale(1.02);
        }
        .btn-paciente { background: #4e73df; color: white; }
        .btn-medico { background: #1cc88a; color: white; }
        .btn-asistente { background: #36b9cc; color: white; }
        .btn-administrador { background: #e74a3b; color: white; }
    </style>
</head>
<body>
    <div class="home-container">
        <div class="home-card">
            <img src="<?php echo APP_URL; ?>/img/logo_azul.png" alt="BioVital">
            <h1>BioVital</h1>
            <p>Sistema de Gestión Clínica</p>
            <div class="btn-group">
                <a href="<?php echo APP_URL; ?>/login/paciente" class="btn-role btn-paciente">
                    <i class="fas fa-user"></i> Acceso Paciente
                </a>
                <a href="<?php echo APP_URL; ?>/login/medico" class="btn-role btn-medico">
                    <i class="fas fa-user-md"></i> Acceso Médico
                </a>
                <a href="<?php echo APP_URL; ?>/login/asistente" class="btn-role btn-asistente">
                    <i class="fas fa-user-nurse"></i> Acceso Asistente
                </a>
                <a href="<?php echo APP_URL; ?>/login/administrador" class="btn-role btn-administrador">
                    <i class="fas fa-user-shield"></i> Acceso Administrador
                </a>
            </div>
        </div>
    </div>
</body>
</html>
